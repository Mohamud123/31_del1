package Spil;

public class Dice {

public static void main (String[] args) {
}
}

